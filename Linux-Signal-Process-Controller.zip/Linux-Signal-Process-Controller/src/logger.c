
#include <stdio.h>
#include <time.h>
#include "../include/logger.h"

void log_activity(const char *action, pid_t pid, const char *result)
{
    FILE *file = fopen("logs/activity.log", "a");

    if (file == NULL)
    {
        perror("Unable to open activity log");
        return;
    }

    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    char timestamp[30];

    if (local != NULL)
        strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", local);
    else
        snprintf(timestamp, sizeof(timestamp), "unknown-time");

    fprintf(file, "[%s] PID=%d | Action=%s | Result=%s\n",
            timestamp, (int)pid, action, result);

    fclose(file);
}
