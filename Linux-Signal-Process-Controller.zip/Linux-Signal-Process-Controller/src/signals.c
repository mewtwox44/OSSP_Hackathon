
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include "../include/signals.h"

int send_process_signal(pid_t pid, int signal_number)
{
    if (pid <= 1 || pid == getpid())
    {
        fprintf(stderr, "Invalid process ID.\n");
        return -1;
    }

    if (kill(pid, signal_number) == -1)
    {
        perror("Failed to send signal");
        return -1;
    }

    return 0;
}

char get_process_state(pid_t pid)
{
    char path[64];
    char state;
    FILE *file;

    if (pid <= 1)
        return '\0';

    snprintf(path, sizeof(path), "/proc/%d/stat", (int)pid);

    file = fopen(path, "r");

    if (file == NULL)
        return '\0';

    /*
       The process name is inside parentheses.
       Read past it to obtain the process state.
    */
    if (fscanf(file, "%*d (%*[^)]) %c", &state) != 1)
        state = '\0';

    fclose(file);
    return state;
}
