
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../include/process.h"
#include "../include/logger.h"

int main()
{
    pid_t pid = -1;
    int choice;

    while (1)
    {
        printf("\n===== LINUX SIGNAL-BASED PROCESS CONTROLLER =====\n");
        printf("1. Start Process\n");
        printf("2. Pause Process\n");
        printf("3. Resume Process\n");
        printf("4. Terminate Process\n");
        printf("5. Restart Process\n");
        printf("6. Show Process Status\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1)
        {
            printf("Invalid input!\n");

            if (pid != -1)
            {
                terminate_process(pid);
            }

            return 1;
        }

        switch (choice)
        {
            case 1:
                if (pid != -1)
                {
                    printf("A process is already managed. Terminate it first.\n");
                }
                else
                {
                    pid = start_process();

                    if (pid != -1)
                        log_activity("START", pid, "SUCCESS");
                    else
                        log_activity("START", -1, "FAILED");
                }
                break;

            case 2:
                if (pid != -1 && pause_process(pid) == 0)
                {
                    printf("Process paused successfully.\n");
                    log_activity("PAUSE", pid, "SUCCESS");
                }
                else
                {
                    printf("Failed to pause process. Start it first.\n");
                    log_activity("PAUSE", pid, "FAILED");
                }
                break;

            case 3:
                if (pid != -1 && resume_process(pid) == 0)
                {
                    printf("Process resumed successfully.\n");
                    log_activity("RESUME", pid, "SUCCESS");
                }
                else
                {
                    printf("Failed to resume process. Start it first.\n");
                    log_activity("RESUME", pid, "FAILED");
                }
                break;

            case 4:
                if (pid != -1 && terminate_process(pid) == 0)
                {
                    log_activity("TERMINATE", pid, "SUCCESS");
                    printf("Process terminated successfully.\n");
                    pid = -1;
                }
                else
                {
                    printf("Failed to terminate process.\n");
                    log_activity("TERMINATE", pid, "FAILED");
                }
                break;

            case 5:
                if (pid != -1)
                {
                    pid_t old_pid = pid;

                    if (restart_process(&pid) == 0)
                    {
                        log_activity("RESTART_OLD", old_pid, "SUCCESS");
                        log_activity("RESTART_NEW", pid, "SUCCESS");
                        printf("Process restarted. New PID: %d\n", pid);
                    }
                    else
                    {
                        log_activity("RESTART", old_pid, "FAILED");
                        printf("Process restart failed.\n");
                        pid = -1;
                    }
                }
                else
                {
                    printf("Start a process before restarting.\n");
                }
                break;

            case 6:
                if (pid != -1)
                {
                    show_process(pid);
                }
                else
                {
                    printf("No managed process. Start one first.\n");
                }
                break;

            case 7:
                if (pid != -1)
                {
                    if (terminate_process(pid) == 0)
                    {
                        log_activity("EXIT_CLEANUP", pid, "SUCCESS");
                        printf("Managed process cleaned up.\n");
                    }
                    else
                    {
                        log_activity("EXIT_CLEANUP", pid, "FAILED");
                        printf("Warning: Could not clean up managed process.\n");
                    }
                }

                printf("Exiting controller.\n");
                return 0;

            default:
                printf("Invalid choice! Enter 1-7.\n");
        }
    }

    return 0;
}
