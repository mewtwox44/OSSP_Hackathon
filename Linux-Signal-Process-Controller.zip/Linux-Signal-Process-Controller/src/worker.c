
#include <stdio.h>
#include <unistd.h>

int main()
{
    int count = 1;

    while (1)
    {
        printf("[WORKER] Process is running. Count: %d\n", count++);
        fflush(stdout);
        sleep(1);
    }

    return 0;
}
