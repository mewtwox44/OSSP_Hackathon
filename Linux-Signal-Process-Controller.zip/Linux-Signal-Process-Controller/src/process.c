
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include "../include/process.h"
#include "../include/signals.h"
#include <stdio.h>

pid_t start_process(void)
{
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork failed");
        return -1;
    }

  
    if (pid == 0)
    {
        FILE *log = fopen("logs/worker.log", "a");

        if (log == NULL)
            _exit(1);

        dup2(fileno(log), STDOUT_FILENO);
        dup2(fileno(log), STDERR_FILENO);
        fclose(log);

        execl("./worker", "worker", (char *)NULL);

        perror("Failed to start worker");
        _exit(1);
    }


    printf("Worker process started successfully. PID: %d\n", (int)pid);
    return pid;
}


int pause_process(pid_t pid)
{
    return send_process_signal(pid, SIGSTOP);
}

int resume_process(pid_t pid)
{
    return send_process_signal(pid, SIGCONT);
}

int terminate_process(pid_t pid)
{
    if (send_process_signal(pid, SIGTERM) == -1)
        return -1;

    if (waitpid(pid, NULL, 0) == -1)
    {
        perror("waitpid failed");
        return -1;
    }

    return 0;
}

int restart_process(pid_t *pid)
{
    if (terminate_process(*pid) == -1)
        return -1;

    *pid = start_process();

    return (*pid == -1) ? -1 : 0;
}


void show_process(pid_t pid)
{
    char state = get_process_state(pid);

    if (state == '\0')
    {
        printf("Process PID %d is not available.\n", (int)pid);
        return;
    }

    printf("Process PID: %d\n", (int)pid);

    switch (state)
    {
        case 'R':
            printf("Status: Running\n");
            break;

        case 'S':
            printf("Status: Sleeping\n");
            break;

        case 'D':
            printf("Status: Waiting for I/O\n");
            break;

        case 'T':
        case 't':
            printf("Status: Stopped or paused\n");
            break;

        case 'Z':
            printf("Status: Zombie\n");
            break;

        case 'I':
            printf("Status: Idle\n");
            break;

        default:
            printf("Status: Other (state %c)\n", state);
    }
}

